var rendelesek = [
    new Rendeles("<strong>#</strong>0001", "Kiss Anna", "Sárberki ltp. 105., Tatabanya", "Készül"),
    new Rendeles("<strong>#</strong>0002", "Kovacs Bela", "Fő utca 12., Budapest", "Futárnál"),
    new Rendeles("<strong>#</strong>0002", "Mészáros Péter", "Fő utca 12., Tatabanya", "Kiszállítva")
];

var rendelt_etelek = [
    new Etelek("Bolognai Spagetti", 3490, 14),
    new Etelek("Margarita Pizza", 3490, 12),
    new Etelek("Paradicsomos Húsgombóc", 3490, 43)
];

const $ = s => document.querySelector(s);

const SuccessModal = new bootstrap.Modal('#SuccessModal', {
    keyboard: false
});

const ErrorModal = new bootstrap.Modal('#ErrorModal', {
    keyboard: false
});

var torlendoId = -1, szerkesztId = -1;

function kiir() {
    statuszCheck();
    idRefress();
    if (window.Radar) Radar.sync();
    szallitasokErteke();
    aktivSzallitasok();
    atlagIdo();
    szallitasiZonak();
    legkozelebbiHatarido();

    $("tbody").innerHTML = "";

    if (rendelesek.length != 0) {
        $("tbody").classList.remove("d-none");
        $(".nincs-rendeles").classList.add("d-none");
        var x = "";
        for (let i = 0; i < rendelesek.length; i++) {
            if (statuszEgyezik(rendelesek[i]) && szovegEgyezik(rendelesek[i], rendelt_etelek[i])) {
                x += tableSor(rendelesek[i], rendelt_etelek[i], i);
            }
        }
        if (x.length != 0) {
            $("tbody").innerHTML = x;
        } else {
            $("tbody").classList.add("d-none");
            $(".nincs-rendeles").innerHTML = "Nincs Találat!";
            $(".nincs-rendeles").classList.remove("d-none");
        }
    } else {
        $("tbody").classList.add("d-none");
        $(".nincs-rendeles").innerHTML = "Nincs Rendelés!";
        $(".nincs-rendeles").classList.remove("d-none");
    }
};

function statuszCheck() {
    for (let i = 0; i < rendelesek.length; i++) {
        if (rendelt_etelek[i].getHatraidoPerc() < 1) {
            rendelesek[i].setStatusz("Kiszállítva");
        }
        if (rendelesek[i].getStatusz() == "Kiszállítva") {
            rendelt_etelek[i].setHatraidoPerc(0);
        }
    }
}

function idRefress() {
    for (let i = 0; i < rendelesek.length; i++) {
        rendelesek[i].setId("<strong>#</strong>" + String(i + 1).padStart(4, "0"));
    }
}

function tableSor(rendeles, rendelt_etelek, index) {
    var ido = (rendelt_etelek.getHatraidoPerc() == 0 ? '<span class="fw-bold text-body">—</span>' : rendelt_etelek.getHatraidoPerc() + " perc");
    var class_name_color = (rendeles.getStatusz() == "Kiszállítva"?"kiszallitva-szin":(rendeles.getStatusz() == "Futárnál"?"futarnal-szin":"keszul-szin"));
    return `<tr class="align-middle m-0 ${statusNoEkezet(rendeles.getStatusz())}" data-bs-toggle="modal" data-bs-target="#SzerkeszthetosegModal" onclick="idBeallit(${index})">
                <td class="form-text p-3 m-0">${rendeles.getId()}</td>
                <td class="form-text p-3 m-0">${rendeles.getUgyfelNev()}<br><span class="form-text">${rendeles.getCim()}</span></td>
                <td class="form-text p-3 m-0">${rendelt_etelek.getEtelNev()}<br><span class="form-text">${rendelt_etelek.getOsszeg()} Ft</span></td>
                <td class="form-text p-3 m-0">${ido}<br><span class="form-text">${rendeles.getStatusz()}</span></td>
                <td class="statusz-csik ${class_name_color}"></td>
            </tr>`;
};

function statusNoEkezet(x) {
    if (x == "Kiszállítva") return "kiszallitva";
    if (x == "Futárnál") return "futar";
    return "keszul";
}

function szallitasokErteke() {
    var osszeg = 0;
    for (let i = 0; i < rendelesek.length; i++) {
        if (rendelesek[i].getStatusz() != "Kiszállítva"){
            osszeg += parseInt(rendelt_etelek[i].getOsszeg());
        }
    }
    $(".osszeg").innerHTML = (osszeg != 0) ? "<span class='fs-4 fw-bold'>" + osszeg + " Ft</span>" : "<span class='fs-4'><i class='bi bi-dash-lg'></i></span>";
};

function aktivSzallitasok() {
    var db = 0, futarDb = 0;
    for (let i = 0; i < rendelesek.length; i++) {
        if (rendelesek[i].getStatusz() == "Készül"){
            db++;
        }else if (rendelesek[i].getStatusz() == "Futárnál"){
            db++; 
            futarDb++;
        }
    }
    if (db != 0) {
        $(".aktiv").innerHTML = "<span class='fs-4 fw-bold'>" + db + "</span><br><span class='form-text'>Aktiv</span>";
    } else {
        $(".aktiv").innerHTML = "<span class='fs-4'><i class='bi bi-dash-lg'></i></span><br><span class='form-text'>Aktiv</span>";
    }
    if (futarDb != 0) {
        $(".futar").innerHTML = "<span class='fs-4 fw-bold'>" + futarDb + "</span><br><span class='form-text'>Futárnál</span>";
    } else {
        $(".futar").innerHTML = "<span class='fs-4'><i class='bi bi-dash-lg'></i></span><br><span class='form-text'>Futárnál</span>";
    }
};

function atlagIdo() {
    var ido = 0;
    var db = 0;
    for (let i = 0; i < rendelesek.length; i++) {
        if (rendelesek[i].getStatusz() != "Kiszállítva") {
            ido += parseInt(rendelt_etelek[i].getHatraidoPerc());
            db++;
        }
    }
    var atlag = parseInt(ido / db);
    if (isNaN(atlag)) {
        $(".atlagIdo").innerHTML = "<span class='fs-4'><i class='bi bi-dash-lg'></i></span><br><span class='form-text'>Atlagos hatralevo ido</span>";
    } else {
        $(".atlagIdo").innerHTML = "<span class='fs-4 fw-bold'>" + atlag + " p</span><br><span class='form-text'>Atlagos hatralevo ido</span>";
    }
};

function szallitasiZonak() {
    var zonak = [];
    for (let i = 0; i < rendelesek.length; i++) {
        var r = rendelesek[i];
        if (r.getStatusz() != "Kiszállítva" && !zonak.includes(r.getCim())) {
            zonak.push(r.getCim());
        }
    }
    if (zonak.length != 0) {
        $(".szallitasiZonak").innerHTML = "<span class='fs-4 fw-bold'>" + zonak.length + "</span><br><span class='form-text'>Aktiv szallitasi zonak</span>";
    } else {
        $(".szallitasiZonak").innerHTML = "<span class='fs-4'><i class='bi bi-dash-lg'></i></span><br><span class='form-text'>Aktiv szallitasi zonak</span>";
    }
};

function legkozelebbiHatarido() {
    var lgkHatarido = rendelt_etelek[0];
    if (rendelesek.length != 0 || lgkHatarido != null) {
        var lgkHatarId = rendelesek[0].getId();
        for (let i = 0; i < rendelesek.length; i++) {
            var r = rendelt_etelek[i];
            if (rendelesek[i].getStatusz() != "Kiszállítva" && r.getHatraidoPerc() != 0) {
                if (r.getHatraidoPerc() < lgkHatarido.getHatraidoPerc()) {
                    lgkHatarido = r;
                    lgkHatarId = rendelesek[i].getId();
                }
            }
        }
        $(".legkozelebbi-ido").innerHTML = "<span class='fs-4 fw-bold'>" + lgkHatarido.getHatraidoPerc() + " p</span><br>Ido";
        $(".legkozelebbi-id").innerHTML = "<span class='fs-4 fw-bold'>" + lgkHatarId + "</span><br>ID";
    } else {
        $(".legkozelebbi-ido").innerHTML = "<span class='fs-4 fw-bold'><i class='bi bi-dash-lg'></i></span><br>Ido";
        $(".legkozelebbi-id").innerHTML = "<span class='fs-4 fw-bold'><i class='bi bi-dash-lg'></i></span><br>ID";
    }

};

function urlapAlaphelyzet() {
    $(".ugyfelNev").value = "";
    $(".szallitasiCim").value = "";
    $(".statusz").value = "Készül";

    $(".etelNev").value = "";
    $(".input_osszeg").value = "";
    $(".hataraidPerc").value = "";

    $(".hozzaadas").classList.remove("d-none");
    $(".mentes").classList.add("d-none");

    szerkesztId = -1;
    torlendoId = -1;
};

$(".uj-rendeles").addEventListener("click", () => urlapAlaphelyzet());
$(".megse").addEventListener("click", () => urlapAlaphelyzet());

$(".szerkeszt").addEventListener("click", () => {
    $(".ugyfelNev").value = rendelesek[szerkesztId].getUgyfelNev();
    $(".szallitasiCim").value = rendelesek[szerkesztId].getCim();
    $(".statusz").value = rendelesek[szerkesztId].getStatusz();

    $(".etelNev").value = rendelt_etelek[szerkesztId].getEtelNev();
    $(".input_osszeg").value = rendelt_etelek[szerkesztId].getOsszeg();
    $(".hataraidPerc").value = rendelt_etelek[szerkesztId].getHatraidoPerc();

    $(".hozzaadas").classList.add("d-none");
    $(".mentes").classList.remove("d-none");
});

function urlapEllenoriz(rendelo_neve, rendelo_cime, etel_neve, etel_ara, etel_ido) {

    if (rendelo_neve == "") {
        $(".hiba_kiir").innerHTML = "HIBA! A <strong>megrendelői név</strong> mező üres! Töltse ki az új rendelés felvételéhez";
        return false
    } else if (rendelo_cime == "") {
        $(".hiba_kiir").innerHTML = "HIBA! A <strong>megrendeléshez szükséges cím</strong> mező üres! Töltse ki az új rendelés felvételéhez";
        return false
    } else if (etel_neve == "") {
        $(".hiba_kiir").innerHTML = "HIBA! Az <strong>étel neve</strong> mező üres! Töltse ki az új rendelés felvételéhez";
        return false
    } else if (etel_ara == "") {
        $(".hiba_kiir").innerHTML = "HIBA! A <strong>étel ára</strong> mező üres! Töltse ki az új rendelés felvételéhez";
        return false
    } else if (etel_ido == "") {
        $(".hiba_kiir").innerHTML = "HIBA! Az <strong>elkésítési idő</strong> mező üres! Töltse ki az új rendelés felvételéhez";
        return false
    } else if (etel_ido < 0) {
        $(".hiba_kiir").innerHTML = "HIBA! A <strong>elkésítési idő</strong> mezőben nem lehet negatív szám! Javítsa ki az új rendelés felvételéhez";
        return false
    } else if (etel_ara == 0) {
        $(".hiba_kiir").innerHTML = "HIBA! Az <strong>étel ára</strong> mező nem lehet 0! Javítsa ki az új rendelés felvételéhez";
        return false
    } else if (etel_ara < 0) {
        $(".hiba_kiir").innerHTML = "HIBA! A <strong>étel ára</strong> mezőben nem lehet negatív szám! Javítsa ki az új rendelés felvételéhez";
        return false
    }else{
        return true;
    }
};

$(".mentes").addEventListener("click", () => {
    var rendelo_neve = $(".ugyfelNev").value;
    var rendelo_cime = $(".szallitasiCim").value;
    var rendeles_statusza = $(".statusz").value;

    var etel_neve = $(".etelNev").value;
    var etel_ara = $(".input_osszeg").value;
    var etel_ido = $(".hataraidPerc").value;

    var valtozott = (
        rendelo_neve != rendelesek[szerkesztId].getUgyfelNev() ||
        rendelo_cime != rendelesek[szerkesztId].getCim() ||
        rendeles_statusza != rendelesek[szerkesztId].getStatusz() ||

        etel_neve != rendelt_etelek[szerkesztId].getEtelNev() ||
        parseInt(etel_ara) != parseInt(rendelt_etelek[szerkesztId].getOsszeg()) ||
        parseInt(etel_ido) != parseInt(rendelt_etelek[szerkesztId].getHatraidoPerc())
    );

    var helyes = urlapEllenoriz(rendelo_neve, rendelo_cime, etel_neve, etel_ara, etel_ido);

    if (helyes && !valtozott) {
        $("#ErrorModal .modal-body").innerHTML = "<p class='m-0'>Nem tortent szerkesztes!</p>";
        ErrorModal.show();
    } else if (helyes && valtozott) {
        rendelesek[szerkesztId].setUgyfelNev(rendelo_neve);
        rendelesek[szerkesztId].setCim(rendelo_cime);
        rendelesek[szerkesztId].setStatusz(rendeles_statusza);

        rendelt_etelek[szerkesztId].setEtelNev(etel_neve);
        rendelt_etelek[szerkesztId].setOsszeg(parseInt(etel_ara));
        rendelt_etelek[szerkesztId].setHatraidoPerc(parseInt(etel_ido));

        $("#SuccessModal .modal-title").innerHTML = "Mentes";
        $("#SuccessModal .modal-body").innerHTML = "<p class='m-0'>Sikeresen mentve!</p>";

        urlapAlaphelyzet();
        kiir();

        SuccessModal.show();
    } else {
        ErrorModal.show();
    }
});

function idBeallit(i) {
    $("#SzerkeszthetosegModal .modal-body").innerHTML = `<p class="m-0">Szeretné törölni vagy szerkeszteni a rendelést a következő ID alapján: ${rendelesek[i].getId()}</p>`;
    torlendoId = i;
    szerkesztId = i;
};

$(".torol").addEventListener("click", () => {
    rendelesek.splice(torlendoId, 1);
    rendelt_etelek.splice(torlendoId, 1);

    torlendoId = -1;
    szerkesztId = -1;
    kiir();
});


$(".hozzaadas").addEventListener("click", () => {
    var rendelo_neve = $(".ugyfelNev").value;
    var rendelo_cime = $(".szallitasiCim").value;
    var rendeles_statusza = $(".statusz").value;

    var etel_neve = $(".etelNev").value;
    var etel_ara = $(".input_osszeg").value;
    var etel_ido = $(".hataraidPerc").value;

    var helyes = urlapEllenoriz(rendelo_neve, rendelo_cime, etel_neve, etel_ara, etel_ido);

    if (helyes) {
        var rendeles = new Rendeles("1", rendelo_neve, rendelo_cime, rendeles_statusza);
        var etel = new Etelek(etel_neve, parseInt(etel_ara), parseInt(etel_ido));

        rendelesek.push(rendeles);
        rendelt_etelek.push(etel);

        urlapAlaphelyzet();
        kiir();

        $("#SuccessModal .modal-title").innerHTML = "Sikeres felvétel!";
        $("#SuccessModal .modal-body").innerHTML = "<p class='m-0'>Sikeresen hozzáadtuk a(z) <span class='success_rendeles'>" + rendeles.getId() + "</span> rendelést a listába!</p>";

        SuccessModal.show();
    } else {
        ErrorModal.show();
    }
});

function statuszEgyezik(r) {
    var select = $(".keres-select").value;
    return select == "Osszes" || select == r.getStatusz();
};

function szovegEgyezik(r, e) {
    var kereses = $(".kereses").value.trim().toLowerCase();
    return kereses == ""
        || r.getUgyfelNev().toLowerCase().includes(kereses)
        || r.getCim().toLowerCase().includes(kereses)
        || e.getEtelNev().toLowerCase().includes(kereses);
};

$(".keres-select").addEventListener("change", kiir);
if ($(".kereses")) $(".kereses").addEventListener("input", kiir);


setInterval(() => {
    var valtozott = false;
    for (let i = 0; i < rendelt_etelek.length; i++) {
        if (rendelt_etelek[i].getHatraidoPerc() > 0) {
            rendelt_etelek[i].setHatraidoPerc(rendelt_etelek[i].getHatraidoPerc() - 1);
            valtozott = true;
        }
    }
    if (valtozott) kiir();
}, (60 * 1000));


setInterval(() => {
    var datum = new Date()
    $(".real-time-ora").innerHTML = datum.getFullYear() + ". " + String((parseInt(datum.getMonth()) + 1)).padStart(2,"0") + ". " + String(datum.getDay()).padStart(2,"0") + ". - " + datum.getHours() + ":" + String(datum.getMinutes()).padStart(2,"0") + ":" + String(datum.getSeconds()).padStart(2,"0");
}, (1000));

kiir();