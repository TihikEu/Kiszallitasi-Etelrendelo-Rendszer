var rendelesek = [
    new Rendeles("<strong>#</strong>0001", "Urmandczi Timea", "Vadasz utca 12., Tatabanya", "Futarnal"),
    new Rendeles("<strong>#</strong>0002", "Kovacs Bela", "Fo utca 12., Tatabanya", "Futarnal")
];
var rendelt_etelek = [
    new Etelek("Kincses Adam", 3490, 7),
    new Etelek("Margarita pizza", 3490, 43)
]

const $ = s => document.querySelector(s);

const SuccessModal = new bootstrap.Modal('#SuccessModal', {
  keyboard: false
});
const ErrorModal = new bootstrap.Modal('#ErrorModal', {
  keyboard: false
});

function kiir() {
    // ✏️ VÁLTOZTATÁS: a statuszCheck() és az idRefress() előre került, hogy a kártyák
    // már a javított adatokból számoljanak (eddig a végén futottak le)
    statuszCheck();
    idRefress();

    szallitasokErteke();
    aktivSzallitasok();
    atlagIdo();
    szallitasiZonak();
    legkozelebbiHatarido();

    $("tbody").innerHTML = "";

    if (rendelesek.length != 0) {
        $("tbody").classList.remove("d-none");
        $(".nincs-rendeles").classList.add("d-none");
        var x = "";
        for (let i = 0; i < rendelesek.length; i++) {
            if (statuszEgyezik(rendelesek[i]) && szovegEgyezik(rendelesek[i], rendelt_etelek[i])) x += tableSor(rendelesek[i], rendelt_etelek[i], i);
        }
        if (x.length !== 0) {
            $("tbody").innerHTML = x;
        } else {
            $("tbody").classList.add("d-none");
            $(".nincs-rendeles").innerHTML = "Nincs Talalat!";
            $(".nincs-rendeles").classList.remove("d-none");
        }
    } else {
        $("tbody").classList.add("d-none");
        $(".nincs-rendeles").innerHTML = "Nincs Rendeles!";
        $(".nincs-rendeles").classList.remove("d-none");
    }
};

// Methodok

// Methodok: Status korigacio

function statuszCheck() {

    for (let i = 0; i < rendelesek.length; i++) {
        if (rendelt_etelek[i].getHatraidoPerc() < 1) {
            rendelesek[i].setStatusz("Kiszallitva")
        }
        if (rendelesek[i].getStatusz() == "Kiszallitva") {
            rendelt_etelek[i].setHatraidoPerc(0);
        }
    }
}

//Methodok: ID refress

function idRefress(){

    for (let i = 0; i < rendelesek.length; i++) {
        rendelesek[i].setId("<strong>#</strong>" + String(i + 1).padStart(4, "0"))
    }
}

// Methodok: Rendeles ID

var rId = (rendelesek.length + 1);

function rendelesId() {

    var x = "<strong>#</strong>";
    for (let i = 0; i < (4 - String(rId).length); i++) {
        x += "0";
    }
    x += String(rId);
    rId++;
    return x;
};

// Methodok: Tabla tr + rendelesId()


function tableSor(rendeles, rendelt_etelek, index) {

    var ido = rendelt_etelek.getHatraidoPerc() === 0 ? '<span class="fw-bold text-dark">—</span>' : rendelt_etelek.getHatraidoPerc() + " perc";
    return `<tr data-bs-toggle="modal" data-bs-target="#exampleModalToggle" onclick="idBeallit(${index})">
                <td class="form-text p-3">${rendeles.getId()}</td>
                <td class="form-text p-3">${rendeles.getUgyfelNev()}</td>
                <td class="form-text p-3">${rendeles.getCim()}</td>
                <td class="form-text p-3">${rendelt_etelek.getEtelNev()}</td>
                <td class="form-text p-3">${rendelt_etelek.getOsszeg()} Ft</td>
                <td class="form-text p-3">${ido}</td>
                <td class="form-text p-3">${rendeles.getStatusz()}</td>
            </tr>`;
};

// Methodok: Szallitasok osszeg

function szallitasokErteke() {

    var osszeg = 0;
    for (let i = 0; i < rendelesek.length; i++) {
        osszeg += rendelt_etelek[i].getOsszeg();
    }
    $(".osszeg").innerHTML = "<span class='fs-4 fw-bold'>" + osszeg.toLocaleString("hu-HU", { style: "currency", currency: "HUF" });
};

// Methodok: Aktiv szallitasok

function aktivSzallitasok() {

    var db = 0, futarDb = 0;
    for (let i = 0; i < rendelesek.length; i++) {
        if (rendelesek[i].getStatusz() === "Keszul") db++;
        else if (rendelesek[i].getStatusz() === "Futarnal") db++, futarDb++;
    }
    if (db !== 0) {
        $(".aktiv").innerHTML = "<span class='fs-4 fw-bold'>" + db + "</span><br>Aktiv";
    } else {
        $(".aktiv").innerHTML = "<span class='fs-4 fw-bold'><i class='bi bi-dash-lg'></i></span><br>Aktiv";
    }
    if (futarDb !== 0) {
        $(".futar").innerHTML = "<span class='fs-4 fw-bold'>" + futarDb + "</span><br>Futarnal";
    } else {
        $(".futar").innerHTML = "<span class='fs-4 fw-bold'><i class='bi bi-dash-lg'></i></span><br>Futarnal";
    }
};

// Methodok: Atlagido

function atlagIdo() {

    var ido = 0;
    var db = 0;
    for (let i = 0; i < rendelesek.length; i++) {
        if (rendelesek[i].getStatusz() !== "Kiszallitva") {
            ido += rendelt_etelek[i].getHatraidoPerc();
            db++;
        }
    }
    var atlag = parseInt(ido / db);
    if (isNaN(atlag)) {
        $(".atlagIdo").innerHTML = "<span class='fs-4 fw-bold'><i class='bi bi-dash-lg fw-bold'></i></span><br>Atlagos hatralevo ido";
    } else {
        $(".atlagIdo").innerHTML = "<span class='fs-4 fw-bold'>" + atlag + " p</span><br>Atlagos hatralevo ido";
    }
};

// Methodok: Szallitasi zonak

function szallitasiZonak() {

    var zonak = [];
    for (let i = 0; i < rendelesek.length; i++) {
        var r = rendelesek[i];
        if (!zonak.includes(r.getCim())) {
            zonak.push(r.getCim());
        }
    }
    if (zonak.length != 0) {
        $(".szallitasiZonak").innerHTML = "<span class='fs-4 fw-bold'>" + zonak.length + "</span><br>Aktiv szallitasi zonak";
    } else {
        $(".szallitasiZonak").innerHTML = "<span class='fs-4 fw-bold'><i class='bi bi-dash-lg'></i></span><br>Aktiv szallitasi zonak";
    }
};

// Methodok: Legkozelebbi = legkisebb hatarido

function legkozelebbiHatarido() {

    var lgkHatarido = null;
    var lgkHatarId = "";

    for (let i = 0; i < rendelesek.length; i++) {
        var r = rendelt_etelek[i];
        if (rendelesek[i].getStatusz() != "Kiszallitva" && r.getHatraidoPerc() != 0) {
            if (lgkHatarido == null || r.getHatraidoPerc() < lgkHatarido.getHatraidoPerc()) {
                lgkHatarido = r;
                lgkHatarId = rendelesek[i].getId();
            }
        }
    }

    if (lgkHatarido == null) {
        $(".legkozelebbi-ido").innerHTML = "<span class='fs-4 fw-bold'><i class='bi bi-dash-lg'></i></span><br>Ido";
        $(".legkozelebbi-id").innerHTML = "<span class='fs-4 fw-bold'><i class='bi bi-dash-lg'></i></span><br>ID";
    } else {
        $(".legkozelebbi-ido").innerHTML = "<span class='fs-4 fw-bold'>" + lgkHatarido.getHatraidoPerc() + " p</span><br>Ido";
        $(".legkozelebbi-id").innerHTML = "<span class='fs-4 fw-bold'>" + lgkHatarId + "</span><br>ID";
    }

};

// Torles

var torlendoId = -1;

function idBeallit(i) {
    torlendoId = i;
};

$(".torol").addEventListener("click", () => {

    rendelesek.splice(torlendoId, 1);
    rendelt_etelek.splice(torlendoId, 1);
    kiir();
});

// Input ellenorzes

function inputUres(x, y){
    if (String(x) === ""){
        return "<p>A(z) <strong>'" + y + "'</strong> input nem lehet ures!</p>";
    }
    return "";
};

function szovegesInputEllenoriz(x, y) {
    var jo = true;
    var helyesek = " .,-0123456789áéíóöőúüű";

    for (let i = 0; i < x.length; i++) {
        var betu = x[i].toLowerCase();
        var angolBetu = (betu >= "a" && betu <= "z");

        if (!angolBetu && !helyesek.includes(betu)) {
            jo = false;
        }
    }

    if (!jo) {
        // ✏️ VÁLTOZTATÁS: az üzenet is említi a vesszőt
        return "<p>A(z) <strong>'" + y + "'</strong> input csak a magyar abc kis- es nagybetuit, szamokat, SPACE-t, kotojelet '-', pontot '.' es vesszot ',' tartalmazhat!</p>";
    } else {
        return "";
    }
}

function egeszSzam(x, y){
    if (!Number.isInteger(Number(x))){
        return "<p>A(z) <strong>'" + y + "'</strong> input csak egesz szam lehet!</p>";
    } else {
        return "";
    }
};

// Uj rendeles hozzaadas

$(".hozzaadas").addEventListener("click", ()=> {

    var rendelo_neve = $(".ugyfelNev").value;
    var rendelo_cime = $(".szallitasiCim").value;
    var rendeles_statusza = $(".statusz").value;

    var etel_neve = $(".etelNev").value;
    var etel_ara = $(".input_osszeg").value;
    var etel_ido = $(".hataraidPerc").value;

     $("#ErrorModal .modal-body").innerHTML = "";

    var helyes = true;

    if (inputUres(rendelo_neve, "Megrendelo Neve") != ""){
        $("#ErrorModal .modal-body").innerHTML += inputUres(rendelo_neve, "Megrendelo Neve");
        helyes = false;

    } else if (szovegesInputEllenoriz(rendelo_neve, "Megrendelo Neve") != ""){
        $("#ErrorModal .modal-body").innerHTML += szovegesInputEllenoriz(rendelo_neve, "Megrendelo Neve");
        helyes = false;

    }

    if (inputUres(rendelo_cime, "Kiszallitas cim") != ""){
        $("#ErrorModal .modal-body").innerHTML += inputUres(rendelo_cime, "Kiszallitas cim");
        helyes = false;

    } else if (szovegesInputEllenoriz(rendelo_cime, "Kiszallitas cim") != ""){
        $("#ErrorModal .modal-body").innerHTML += szovegesInputEllenoriz(rendelo_cime, "Kiszallitas cim");
        helyes = false;

    }

    if (inputUres(etel_neve, "Etel neve") != ""){
        $("#ErrorModal .modal-body").innerHTML += inputUres(etel_neve, "Etel neve");
        helyes = false;

    } else if (szovegesInputEllenoriz(etel_neve, "Etel neve") != ""){
        $("#ErrorModal .modal-body").innerHTML += szovegesInputEllenoriz(etel_neve, "Etel neve");
        helyes = false;

    }

    if (inputUres(etel_ara, "Osszeg ( Ft )") != ""){
        $("#ErrorModal .modal-body").innerHTML += inputUres(etel_ara, "Osszeg ( Ft )");
        helyes = false;

    } else if (egeszSzam(etel_ara, "Osszeg ( Ft )") != ""){
        $("#ErrorModal .modal-body").innerHTML += egeszSzam(etel_ara, "Osszeg ( Ft )");
        helyes = false;

    }

    if(inputUres(etel_ido, "Kiszallitasi Ido ( Perc )") != ""){
        $("#ErrorModal .modal-body").innerHTML += inputUres(etel_ido, "Kiszallitasi Ido ( Perc )");
        helyes = false;

    } else if (egeszSzam(etel_ido, "Kiszallitasi Ido ( Perc )") != ""){
        $("#ErrorModal .modal-body").innerHTML += egeszSzam(etel_ido, "Kiszallitasi Ido ( Perc )");
        helyes = false;

    }

    if(helyes){
        var rendeles = new Rendeles(rendelesId(), rendelo_neve, rendelo_cime, rendeles_statusza);
        var etel = new Etelek(etel_neve, etel_ara, etel_ido);

        rendelesek.push(rendeles);
        rendelt_etelek.push(etel);

        $(".ugyfelNev").value = "";
        $(".szallitasiCim").value = "";
        $(".statusz").value = "Keszul";

        $(".etelNev").value = "";
        $(".input_osszeg").value = "";
        $(".hataraidPerc").value = "";

        kiir();

        $(".success_rendeles").innerHTML = rendeles.getId();

        SuccessModal.show();
    } else {
        ErrorModal.show();
    }
});

// Kereses

function statuszEgyezik(r) {

    return $(".keres-select").value === "Osszes" || $(".keres-select").value === r.getStatusz();
};

function szovegEgyezik(r, e) {

    var kereses = $(".kereses").value.trim().toLowerCase();
    return kereses === ""
        || r.getUgyfelNev().toLowerCase().includes(kereses)
        || r.getCim().toLowerCase().includes(kereses)
        || e.getEtelNev().toLowerCase().includes(kereses);
};

// Ai

$(".keres-select").addEventListener("change", kiir);
if ($(".kereses")) $(".kereses").addEventListener("input", kiir);

//

kiir();