/* ===== CURSOR GLOW EFFEKT =====
   A CSS a --mx / --my változókat használja a radial-gradient pozíciójához.
   Itt minden érintett elemre az egérpozíciót az ELEM saját bal felső sarkához
   viszonyítva állítjuk be, így a fény folytonosan "átfolyik" a cellákon és kártyákon. */

(function () {
    "use strict";

    // Ugyanazok az elemek, mint a CSS-ben a "FÉNY EFFEKT" szelektorban
    const GLOW_SELECTOR = ".rendelesek tbody td:not(.statusz-csik), .card, .uj-rendeles, .glow";
    const OFF = "-999px";

    // A fény sugara a CSS változóból (--glow-size), alapértelmezés: 140px
    const glowSize = parseFloat(
        getComputedStyle(document.documentElement).getPropertyValue("--glow-size")
    ) || 140;

    let mouseX = null;
    let mouseY = null;
    let ticking = false;

    function applyGlow() {
        ticking = false;

        const elements = document.querySelectorAll(GLOW_SELECTOR);

        for (const el of elements) {
            if (mouseX === null) {
                resetEl(el);
                continue;
            }

            const rect = el.getBoundingClientRect();

            // Ha a kurzor a fény hatósugarán kívül van, nem számolunk feleslegesen
            const outside =
                mouseX < rect.left - glowSize ||
                mouseX > rect.right + glowSize ||
                mouseY < rect.top - glowSize ||
                mouseY > rect.bottom + glowSize;

            if (outside) {
                resetEl(el);
                continue;
            }

            el.style.setProperty("--mx", (mouseX - rect.left) + "px");
            el.style.setProperty("--my", (mouseY - rect.top) + "px");
        }
    }

    function resetEl(el) {
        if (el.style.getPropertyValue("--mx") !== OFF) {
            el.style.setProperty("--mx", OFF);
            el.style.setProperty("--my", OFF);
        }
    }

    function schedule() {
        if (!ticking) {
            ticking = true;
            requestAnimationFrame(applyGlow);
        }
    }

    // Egér / érintés mozgás
    document.addEventListener("pointermove", (e) => {
        mouseX = e.clientX;
        mouseY = e.clientY;
        schedule();
    }, { passive: true });

    // Ha a kurzor elhagyja az ablakot, a fény eltűnik
    document.documentElement.addEventListener("pointerleave", () => {
        mouseX = null;
        mouseY = null;
        schedule();
    });

    // Görgetésnél (oldal vagy rendelések lista) is frissítjük, ha az egér áll
    window.addEventListener("scroll", schedule, { passive: true });
    document.addEventListener("scroll", schedule, { passive: true, capture: true });

    // A táblázat sorait a kiir() újraépíti (innerHTML), ilyenkor újra rá kell tenni a fényt
    function observeTable() {
        const tbody = document.querySelector(".rendelesek tbody");
        if (!tbody) return;

        new MutationObserver(schedule).observe(tbody, { childList: true });
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", observeTable);
    } else {
        observeTable();
    }
})();