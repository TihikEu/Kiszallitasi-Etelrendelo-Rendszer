/* ===== CURSOR GLOW EFFEKT (kártyák + táblázat cellák) =====
   A fény alapból nem látszik: csak akkor jelenik meg, ha a kurzor
   TÉNYLEGESEN az adott kártyán vagy cellán van. A CSS a --mx / --my
   változókat használja a radial-gradient pozíciójához. */

(function () {
    "use strict";

    const GLOW_SELECTOR = ".card, .rendelesek tbody td:not(.statusz-csik)";
    const OFF = "-999px";

    let mouseX = null;
    let mouseY = null;
    let ticking = false;

    function applyGlow() {
        ticking = false;

        const elements = document.querySelectorAll(GLOW_SELECTOR);

        for (const el of elements) {
            if (mouseX === null) {
                resetEl(el);
                continue;
            }

            const rect = el.getBoundingClientRect();

            // Cellánál a SOR (tr) területe számít: ha a kurzor a soron van,
            // a sor minden cellája világít; kártyánál a kártya saját területe.
            const area = el.tagName === "TD" ? el.parentElement.getBoundingClientRect() : rect;

            const inside =
                mouseX >= area.left &&
                mouseX <= area.right &&
                mouseY >= area.top &&
                mouseY <= area.bottom;

            if (!inside) {
                resetEl(el);
                continue;
            }

            // A koordináta az adott cellához képest van, így a fény folytonosan
            // átfolyik a sor celláin
            el.style.setProperty("--mx", (mouseX - rect.left) + "px");
            el.style.setProperty("--my", (mouseY - rect.top) + "px");
        }
    }

    function resetEl(el) {
        if (el.style.getPropertyValue("--mx") !== OFF) {
            el.style.setProperty("--mx", OFF);
            el.style.setProperty("--my", OFF);
        }
    }

    function schedule() {
        if (!ticking) {
            ticking = true;
            requestAnimationFrame(applyGlow);
        }
    }

    // Egér / érintés mozgás
    document.addEventListener("pointermove", (e) => {
        mouseX = e.clientX;
        mouseY = e.clientY;
        schedule();
    }, { passive: true });

    // Ha a kurzor elhagyja az ablakot, a fény eltűnik
    document.documentElement.addEventListener("pointerleave", () => {
        mouseX = null;
        mouseY = null;
        schedule();
    });

    // Görgetésnél is frissítjük, ha az egér áll
    window.addEventListener("scroll", schedule, { passive: true });
    document.addEventListener("scroll", schedule, { passive: true, capture: true });

    // A táblázat sorait a kiir() újraépíti (innerHTML), ilyenkor újra ellenőrizni kell
    function observeTable() {
        const tbody = document.querySelector(".rendelesek tbody");
        if (!tbody) return;

        new MutationObserver(schedule).observe(tbody, { childList: true });
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", observeTable);
    } else {
        observeTable();
    }
})();