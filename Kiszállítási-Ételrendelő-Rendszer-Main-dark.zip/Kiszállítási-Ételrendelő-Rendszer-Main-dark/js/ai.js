/* ===== CURSOR GLOW EFFEKT (kártyák + szűrő + új rendelés űrlap) =====
   A fény alapból nem látszik: csak akkor jelenik meg, ha a kurzor
   TÉNYLEGESEN az adott elemen van.

   A fény KÉSVE követi az egeret és be-/kifakul (olyan, mint egy transition).
   A radial-gradient pozícióját CSS transition nem tudja animálni, ezért
   itt simítjuk, és a CSS ezeket a változókat használja:
     --mx / --my : a fény helye (px)
     --ga        : a fény erőssége (0 = nincs, 1 = teljes)

   Hangolás:
     POS_DELAY  - minél nagyobb, annál lustábban követi az egeret (ms)
     FADE_DELAY - minél nagyobb, annál lassabban fakul be / ki (ms) */

(function () {
    "use strict";

    const GLOW_SELECTOR = ".card, .filter, .collapse-inner";
    const POS_DELAY = 90;
    const FADE_DELAY = 140;

    const states = new Map();   // elem -> { x, y, a, tx, ty, ta }
    let mouseX = null;
    let mouseY = null;
    let targetsQueued = false;
    let running = false;
    let last = 0;

    function stateOf(el) {
        let s = states.get(el);
        if (!s) {
            s = { x: 0, y: 0, a: 0, tx: 0, ty: 0, ta: 0 };
            states.set(el, s);
        }
        return s;
    }

    /* ---------- célok kiszámítása (hol van az egér az elemekhez képest) ---------- */
    function updateTargets() {
        targetsQueued = false;

        for (const el of document.querySelectorAll(GLOW_SELECTOR)) {
            const s = stateOf(el);

            if (mouseX === null) {
                s.ta = 0;
                continue;
            }

            const rect = el.getBoundingClientRect();
            const inside =
                mouseX >= rect.left && mouseX <= rect.right &&
                mouseY >= rect.top && mouseY <= rect.bottom;

            if (!inside) {
                s.ta = 0;       // a hely marad, a fény csak elhalványul
                continue;
            }

            s.tx = mouseX - rect.left;
            s.ty = mouseY - rect.top;
            s.ta = 1;

            // ha a fény épp nem látszik, oda ugrik ahol az egér belépett (nem csúszik be messziről)
            if (s.a < 0.02) {
                s.x = s.tx;
                s.y = s.ty;
            }
        }

        start();
    }

    function queueTargets() {
        if (!targetsQueued) {
            targetsQueued = true;
            requestAnimationFrame(updateTargets);
        }
    }

    /* ---------- animáció (simítás) ---------- */
    function start() {
        if (running) return;
        running = true;
        last = performance.now();
        requestAnimationFrame(tick);
    }

    function tick(now) {
        const dt = Math.min(64, now - last);
        last = now;

        // képkockasebességtől független simítás
        const kPos = 1 - Math.exp(-dt / POS_DELAY);
        const kFade = 1 - Math.exp(-dt / FADE_DELAY);

        let busy = false;

        for (const [el, s] of states) {
            s.x += (s.tx - s.x) * kPos;
            s.y += (s.ty - s.y) * kPos;
            s.a += (s.ta - s.a) * kFade;

            const settled =
                Math.abs(s.tx - s.x) < 0.2 &&
                Math.abs(s.ty - s.y) < 0.2 &&
                Math.abs(s.ta - s.a) < 0.005;

            if (settled) {
                s.x = s.tx;
                s.y = s.ty;
                s.a = s.ta;
            } else {
                busy = true;
            }

            el.style.setProperty("--mx", s.x.toFixed(1) + "px");
            el.style.setProperty("--my", s.y.toFixed(1) + "px");
            el.style.setProperty("--ga", s.a.toFixed(3));
        }

        if (busy) {
            requestAnimationFrame(tick);
        } else {
            running = false;
        }
    }

    /* ---------- események ---------- */
    document.addEventListener("pointermove", (e) => {
        mouseX = e.clientX;
        mouseY = e.clientY;
        queueTargets();
    }, { passive: true });

    // Ha a kurzor elhagyja az ablakot, a fény elhalványul
    document.documentElement.addEventListener("pointerleave", () => {
        mouseX = null;
        mouseY = null;
        queueTargets();
    });

    // Görgetésnél is frissítjük, ha az egér áll
    window.addEventListener("scroll", queueTargets, { passive: true });
    document.addEventListener("scroll", queueTargets, { passive: true, capture: true });
})();