/* ===== RADAR TÉRKÉP =====
   A pontokat közvetlenül a rendelesek tömbből olvassa (main.js),
   nem a táblázatból, ezért:

   - a szűrés / keresés nem befolyásolja a pontokat
   - az idRefress() újraszámozása nem mozgatja el a pontokat
   - minden rendelés objektum kap egy állandó belső számot (WeakMap),
     ebből számolódik a pont helye, így ugyanaz a rendelés mindig ugyanott marad
   - kiszállított rendelés pontja eltűnik, törölté is, újé megjelenik

   A frissítést a tbody változása indítja el (a kiir() mindig újraépíti),
   így sem a Rendeles.js, sem a main.js nem módosul. */

(function () {
    "use strict";

    const SVG_NS = "http://www.w3.org/2000/svg";
    const RADIUS = 42;        // a középponttól max. ennyi %
    const LEAVE_MS = 400;     // a CSS .leaving átmenetével egyezzen
    const GOLDEN_ANGLE = 137.508;

    const points = new Map();      // Rendeles objektum -> { dot, line }
    const uids = new WeakMap();    // Rendeles objektum -> állandó szám
    let nextUid = 1;

    let map = null;
    let linesSvg = null;
    let pointsLayer = null;
    let scheduled = false;

    /* ---------- felépítés ---------- */
    function init() {
        map = document.querySelector(".map");
        if (!map || map.querySelector(".radar-sweep")) return;

        const sweep = document.createElement("div");
        sweep.className = "radar-sweep";

        linesSvg = document.createElementNS(SVG_NS, "svg");
        linesSvg.setAttribute("class", "radar-lines");

        const center = document.createElement("div");
        center.className = "radar-center";

        pointsLayer = document.createElement("div");

        map.append(sweep, linesSvg, center, pointsLayer);
    }

    /* ---------- állandó azonosító + pozíció ---------- */
    function uidOf(order) {
        if (!uids.has(order)) uids.set(order, nextUid++);
        return uids.get(order);
    }

    // Az arany szög miatt az egymás utáni számok szépen szétszóródnak a körön
    function positionFor(uid) {
        const angle = (uid * GOLDEN_ANGLE) % 360;
        const distance = 0.35 + ((uid * 37) % 60) / 100;

        const rad = (angle * Math.PI) / 180;
        const d = distance * RADIUS;

        return {
            x: 50 + Math.sin(rad) * d,
            y: 50 - Math.cos(rad) * d
        };
    }

    /* ---------- pont hozzáadása / eltávolítása ---------- */
    function setStatus(p, status) {
        for (const el of [p.dot, p.line]) {
            el.classList.remove("st-keszul", "st-futarnal");
            if (status) el.classList.add("st-" + status);
        }
    }

    // A rendelés ID-ja HTML-t tartalmaz (<strong>#</strong>0001), a címkéhez csak a szöveg kell.
    // Az idRefress() átszámozhatja, ezért minden szinkronnál frissítjük.
    function labelOf(order) {
        return String(order.getId()).replace(/<[^>]*>/g, "");
    }

    function addPoint(order, status) {
        const { x, y } = positionFor(uidOf(order));

        const line = document.createElementNS(SVG_NS, "line");
        line.setAttribute("x1", "50%");
        line.setAttribute("y1", "50%");
        line.setAttribute("x2", x + "%");
        line.setAttribute("y2", y + "%");
        linesSvg.appendChild(line);

        const dot = document.createElement("div");
        dot.className = "radar-point";
        dot.style.left = x + "%";
        dot.style.top = y + "%";
        dot.dataset.label = labelOf(order);
        if (y < 20) dot.classList.add("below"); // felül ne vágja le a térkép széle
        pointsLayer.appendChild(dot);

        const p = { dot, line };
        setStatus(p, status);
        points.set(order, p);
    }

    function removePoint(order) {
        const p = points.get(order);
        if (!p) return;

        points.delete(order);
        p.dot.classList.add("leaving");
        p.line.classList.add("leaving");

        setTimeout(() => {
            p.dot.remove();
            p.line.remove();
        }, LEAVE_MS);
    }

    /* ---------- szinkron a rendelesek tömbbel ---------- */
    function readActiveOrders() {
        const active = new Map();

        if (typeof rendelesek === "undefined") return active;

        for (const r of rendelesek) {
            const s = r.getStatusz();
            if (s === "Kiszallitva") continue;

            active.set(r, s === "Futarnal" ? "futarnal" : "keszul");
        }

        return active;
    }

    function sync() {
        scheduled = false;
        if (!map) return;

        const active = readActiveOrders();

        // törölt / kiszállított rendelések pontjai lemennek
        for (const order of [...points.keys()]) {
            if (!active.has(order)) removePoint(order);
        }

        // új rendelések pontjai megjelennek, a meglévők maradnak a helyükön,
        // de a színük követi a státuszt (pl. Készül -> Futárnál)
        for (const [order, status] of active) {
            if (points.has(order)) {
                const p = points.get(order);
                setStatus(p, status);
                p.dot.dataset.label = labelOf(order);
            } else {
                addPoint(order, status);
            }
        }
    }

    function schedule() {
        if (scheduled) return;
        scheduled = true;
        requestAnimationFrame(sync);
    }

    /* ---------- indulás ---------- */
    function start() {
        init();
        if (!map) return;

        // a kiir() minden alkalommal újraépíti a tbody-t, ez jelzi a változást
        const tbody = document.querySelector(".rendelesek tbody");
        if (tbody) {
            new MutationObserver(schedule).observe(tbody, { childList: true });
        }

        sync();
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", start);
    } else {
        start();
    }

    window.Radar = { sync };
})();